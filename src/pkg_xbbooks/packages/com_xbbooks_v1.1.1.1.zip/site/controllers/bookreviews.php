<?php
/*******
 * @package xbBooks
 * @filesource site/controllers/bookreviews.php
 * @version 1.0.3.7 25th January 2023
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2021
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 ******/
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;

class XbbooksControllerBookreviews extends FormController {
	
}